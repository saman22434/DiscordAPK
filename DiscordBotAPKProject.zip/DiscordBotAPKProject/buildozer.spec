[app]
title = Farsian Community Bot
package.name = farsiancommunitybot
package.domain = org.farsiancommunity
source.dir = .
source.include_exts = py,png,jpg,kv,json
version = 1.0
requirements = python3,kivy,discord.py,aiohttp
orientation = portrait
fullscreen = 0
android.permissions = INTERNET,WAKE_LOCK,POST_NOTIFICATIONS
android.api = 35
android.minapi = 23
android.archs = arm64-v8a,armeabi-v7a
android.accept_sdk_license = True

[buildozer]
log_level = 2
warn_on_root = 1

[app:android]
android.enable_androidx = True
