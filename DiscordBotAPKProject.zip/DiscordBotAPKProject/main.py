import asyncio
import threading
import traceback
from datetime import datetime

import discord
from discord import app_commands
from discord.ext import commands
from kivy.app import App
from kivy.clock import Clock
from kivy.core.window import Window
from kivy.lang import Builder
from kivy.properties import StringProperty, BooleanProperty

KV = r'''
#:import dp kivy.metrics.dp

BoxLayout:
    orientation: 'vertical'
    padding: dp(18)
    spacing: dp(12)
    canvas.before:
        Color:
            rgba: .055, .055, .07, 1
        Rectangle:
            pos: self.pos
            size: self.size
    Label:
        text: 'Discord Bot'
        font_size: '26sp'
        bold: True
        size_hint_y: None
        height: dp(45)
    Label:
        text: root.status_text
        color: (.75,.75,.8,1)
        size_hint_y: None
        height: dp(42)
        text_size: self.width, None
        halign: 'center'
    TextInput:
        id: token
        hint_text: 'Bot Token'
        password: True
        multiline: False
        size_hint_y: None
        height: dp(52)
        disabled: root.running
    BoxLayout:
        size_hint_y: None
        height: dp(52)
        spacing: dp(10)
        Button:
            text: 'START'
            disabled: root.running
            on_release: app.start_bot(token.text)
        Button:
            text: 'STOP'
            disabled: not root.running
            on_release: app.stop_bot()
    ScrollView:
        Label:
            text: root.log_text
            size_hint_y: None
            height: self.texture_size[1] + dp(20)
            text_size: self.width - dp(20), None
            valign: 'top'
            padding: dp(10), dp(10)
'''

CONFIG = {
    'botName': 'Farsian-Community',
    'statusUpdateTime': 300000,
}


def make_bot(log):
    intents = discord.Intents.none()
    intents.guilds = True
    intents.members = True
    intents.guild_messages = True
    intents.message_content = True

    bot = commands.Bot(command_prefix='!', intents=intents)

    @bot.event
    async def on_ready():
        log(f'Logged in as {bot.user}')
        log(f'Servers: {len(bot.guilds)}')
        await update_status()
        for guild in bot.guilds:
            try:
                await bot.tree.sync(guild=guild)
                log(f'Commands registered in: {guild.name}')
            except Exception as e:
                log(f'Command registration failed: {e}')
        log('DONE | Application/Bot is up and running.')

    @bot.event
    async def on_guild_join(guild):
        await update_status()
        try:
            await bot.tree.sync(guild=guild)
            log(f'Commands registered in: {guild.name}')
        except Exception as e:
            log(f'Command registration failed: {e}')

    async def update_status():
        if not bot.user:
            return
        total = sum((g.member_count or 0) for g in bot.guilds)
        await bot.change_presence(
            status=discord.Status.online,
            activity=discord.Streaming(name=f'{total} Members', url='https://www.twitch.tv/FarsianCommunity')
        )
        log(f'Status Updated: {total} Members')

    async def periodic_status():
        await bot.wait_until_ready()
        while not bot.is_closed():
            await asyncio.sleep(CONFIG['statusUpdateTime'] / 1000)
            await update_status()

    @bot.tree.command(name='testping', description='Shows the bot latency')
    async def testping(interaction: discord.Interaction):
        await interaction.response.send_message(
            f'Latency is {round((discord.utils.utcnow()-interaction.created_at).total_seconds()*1000)}ms. API Latency is {round(bot.latency*1000)}ms'
        )

    @bot.tree.command(name='nameserver', description='𝐅𝐚𝐫𝐬𝐢𝐚𝐧 𝐂𝐨𝐦𝐦𝐮𝐧𝐢𝐭𝐲')
    async def nameserver(interaction: discord.Interaction):
        await interaction.response.send_message('𝐅𝐚𝐫𝐬𝐢𝐚𝐧 𝐂𝐨𝐦𝐦𝐮𝐧𝐢𝐭𝐲')

    @bot.tree.command(name='ban', description='Ban a member')
    @app_commands.default_permissions(ban_members=True)
    @app_commands.describe(user='Member to ban', reason='Reason for the ban')
    async def ban(interaction: discord.Interaction, user: discord.User, reason: str = 'No reason provided'):
        member = interaction.guild.get_member(user.id) if interaction.guild else None
        if member is None:
            try: member = await interaction.guild.fetch_member(user.id)
            except Exception: member = None
        if not member:
            return await interaction.response.send_message('That user is not a member of this server.', ephemeral=True)
        if not member.bannable:
            return await interaction.response.send_message('I cannot ban that member. Check my role position and permissions.', ephemeral=True)
        await member.ban(reason=reason)
        await interaction.response.send_message(f'Banned {user}. Reason: {reason}')

    @bot.tree.command(name='kick', description='Kick a member')
    @app_commands.default_permissions(kick_members=True)
    @app_commands.describe(user='Member to kick', reason='Reason for the kick')
    async def kick(interaction: discord.Interaction, user: discord.User, reason: str = 'No reason provided'):
        member = interaction.guild.get_member(user.id) if interaction.guild else None
        if member is None:
            try: member = await interaction.guild.fetch_member(user.id)
            except Exception: member = None
        if not member:
            return await interaction.response.send_message('That user is not a member of this server.', ephemeral=True)
        if not member.kickable:
            return await interaction.response.send_message('I cannot kick that member. Check my role position and permissions.', ephemeral=True)
        await member.kick(reason=reason)
        await interaction.response.send_message(f'Kicked {user}. Reason: {reason}')

    @bot.tree.command(name='timeout', description='Timeout a member')
    @app_commands.default_permissions(moderate_members=True)
    @app_commands.describe(user='Member to timeout', minutes='Timeout duration in minutes', reason='Reason for the timeout')
    async def timeout(interaction: discord.Interaction, user: discord.User, minutes: app_commands.Range[int, 1, 40320], reason: str = 'No reason provided'):
        member = interaction.guild.get_member(user.id) if interaction.guild else None
        if member is None:
            try: member = await interaction.guild.fetch_member(user.id)
            except Exception: member = None
        if not member:
            return await interaction.response.send_message('That user is not a member of this server.', ephemeral=True)
        if not member.moderatable:
            return await interaction.response.send_message('I cannot timeout that member. Check my role position and permissions.', ephemeral=True)
        await member.timeout(datetime.now(datetime.now().astimezone().tzinfo) + __import__('datetime').timedelta(minutes=minutes), reason=reason)
        await interaction.response.send_message(f'Timed out {user} for {minutes} minute(s). Reason: {reason}')

    @bot.tree.command(name='clear', description='Delete messages')
    @app_commands.default_permissions(manage_messages=True)
    @app_commands.describe(amount='Number of messages to delete')
    async def clear(interaction: discord.Interaction, amount: app_commands.Range[int, 1, 100]):
        deleted = await interaction.channel.purge(limit=amount)
        await interaction.response.send_message(f'Deleted {len(deleted)} message(s).', ephemeral=True)

    bot.setup_hook = lambda: bot.loop.create_task(periodic_status())
    return bot


class BotApp(App):
    status_text = StringProperty('Stopped')
    log_text = StringProperty('Ready. Enter your Discord Bot Token.\n')
    running = BooleanProperty(False)

    def build(self):
        Window.clearcolor = (0.055, 0.055, 0.07, 1)
        return Builder.load_string(KV)

    def add_log(self, message):
        def update(_dt):
            stamp = datetime.now().strftime('%H:%M:%S')
            self.log_text += f'[{stamp}] {message}\n'
        Clock.schedule_once(update)

    def start_bot(self, token):
        token = (token or '').strip()
        if not token:
            self.status_text = 'Enter a bot token.'
            return
        self.running = True
        self.status_text = 'Starting…'
        self.add_log('Starting Discord bot…')
        self.bot = make_bot(self.add_log)

        def runner():
            try:
                asyncio.run(self.bot.start(token))
            except Exception as e:
                self.add_log(f'Bot stopped: {e}')
                self.add_log(traceback.format_exc())
                Clock.schedule_once(lambda dt: self._stopped())
        self.thread = threading.Thread(target=runner, daemon=True)
        self.thread.start()

    def _stopped(self):
        self.running = False
        self.status_text = 'Stopped'

    def stop_bot(self):
        if getattr(self, 'bot', None):
            self.add_log('Stopping bot…')
            try:
                asyncio.run_coroutine_threadsafe(self.bot.close(), self.bot.loop)
            except Exception as e:
                self.add_log(str(e))
        self._stopped()


if __name__ == '__main__':
    BotApp().run()
